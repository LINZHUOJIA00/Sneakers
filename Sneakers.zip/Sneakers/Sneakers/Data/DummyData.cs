﻿using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using Sneakers.Data;
using Sneakers.Models;
using System.Collections.Generic;
using System.Linq;

public class DummyData
{
    public static void Initialize(IApplicationBuilder app)
    {
        using (var serviceScope = app.ApplicationServices.GetService<IServiceScopeFactory>().CreateScope())
        {
            var context = serviceScope.ServiceProvider.GetService<ApplicationDbContext>();
            context.Database.EnsureCreated();
            //context.Database.Migrate();

            // Look for any Brands.
            if (context.Brands.Any())
            {
                return;   // DB has already been seeded
            }

            var Brands = DummyData.GetBrands().ToArray();
            context.Brands.AddRange(Brands);
            context.SaveChanges();

            var Technologies = DummyData.GetTechnologies(context).ToArray();
            context.Technologies.AddRange(Technologies);
            context.SaveChanges();
        }
    }

    public static List<Brand> GetBrands()
    {
        List<Brand> Brands = new List<Brand>() {
                        new Brand() {
                Name = "Nike",
                Country ="USA",
                Value = "$110",
            },
            new Brand() {
                Name = "Adidas",
                Country = "Germany",
                Value = "$100",
            },
            new Brand() {
                Name = "Lining",
                Country = "China",
                Value = "$60",
            },
             new Brand() {
                Name = "Anta",
                Country = "China",
                Value = "$50",
            },
               new Brand() {
                Name = "Puma",
                Country = "Germany",
                Value = "$80",
            },
                new Brand() {
                Name = "Reebook",
                Country = "USA",
                Value = "$85",
            },
        };

        return Brands;
    }

    public static List<Technology> GetTechnologies(ApplicationDbContext context)
    {
        List<Technology> Technologies = new List<Technology>() {
            new Technology {
                Insoles = "AIR MAX",
                Material = "MARS",
                Feel = "Unparalleled",
            },
            new Technology() {
                Insoles = "Boost",
                Material = "4D Face",
                Feel = "Comfortable",
            },
            new Technology() {
                Insoles = "Nut",
                Material = "Renuf",
                Feel = "Damping",
            },
            new Technology() {
                Insoles = "carbon palte",
                Material = "3D Face",
                Feel = "suitable",
            },
            new Technology() {
                Insoles = "bradyseism",
                Material = "3D Face",
                Feel = "Damping",
            },
            new Technology() {
                Insoles = "carbon palte",
                Material = "4D Face",
                Feel = "Unparalleled",
            },
        };

        return Technologies;
    }
}