﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Sneakers.Models
{
    public class Technology
    {
        [Key]
        

        public string Insoles { get; set; }
        public string Material { get; set; }
        public string Feel { get; set; }
        
        public Brand Brand { get; set; }

    }
}
